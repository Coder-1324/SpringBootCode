package com.UserRepository.demo.services;

public class UserServiceImpl {

}
