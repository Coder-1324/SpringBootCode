package com.engg.journal.controller;

public class journalEntries {

}
